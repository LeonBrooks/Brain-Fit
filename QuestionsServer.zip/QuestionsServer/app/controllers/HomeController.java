package controllers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Random;
import java.util.OptionalInt;

import play.mvc.*;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import models.*;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import play.Logger;
import javax.inject.Inject;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    @Inject
    private MDB db;

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok("ok");
    }

    public Result getId(String email){
        Logger.info("getId");

        User u = db.getUser(email);
        if(u == null){return badRequest("-1");}

        return ok(Integer.toString(u.getId()));
    }

    public Result getUser(int id){
        Logger.info("getUser");

        User  u = db.getUser(id);
        if(u == null){return badRequest("{ }");}

        ObjectNode searchResult = Json.newObject();

        searchResult.put("id", u.getId());
        searchResult.put("username", u.getUsername());
        searchResult.put("email", u.getEmail());

        ArrayNode inbox = searchResult.arrayNode();
        for (Integer i:u.getInbox()) {
            inbox.add(i);
        }

        searchResult.put("inbox", inbox);
        searchResult.put("team", u.getTeam());
        searchResult.put("points", u.getPoints());
        searchResult.put("gamesWon", u.getGamesWon());
        searchResult.put("gamesLose", u.getGamesLose());
        searchResult.put("questionSentOn", u.getQuestionsSentOn());
        searchResult.put("questionsRight", u.getQuestionsRight());
        searchResult.put("questionsWrong", u.getQuestionsWrong());


        Result res = ok(searchResult);
        return  res;
    }

    public Result updateUser(int id, String username, String email, int team, int points, int gamesWon, int gamesLose, int questionsSentOn, int questionsRight, int questionsWrong){
        Logger.info("updateUser");

        User u = db.getUser(id);

        if(u!=null){
            u.setUsername(username);
            u.setEmail(email);
            u.setTeam(team);
            u.setPoints(points);
            u.setGamesWon(gamesWon);
            u.setGamesLose(gamesLose);
            u.setQuestionsSentOn(questionsSentOn);
            u.setQuestionsRight(questionsRight);
            u.setQuestionsWrong(questionsWrong);

            db.update(u);
        }else{
            Logger.info("user not found");
            return badRequest("User doesn't exist in db");
        }

        return ok("updated User");
    }

    public Result createUser(String username, String email){
        Logger.info("create User");
        int id = db.nextUID();
        User u = new User(id, username, email, new HashSet<Integer>(), -1,0,0,0,0,0,0);
        db.insert(u);

        return getUser(id);
    }

    public Result getTeam(int id){
        Logger.info("get Team");

        Team t = db.getTeam(id);
        if(t == null){return badRequest("{ }");}

        ObjectNode searchResult = Json.newObject();
        searchResult.put("id", t.getId());
        searchResult.put("teamname", t.getTeamname());

        ArrayNode users = searchResult.arrayNode();
        for (Integer u:t.getUsers()) {
            users.add(u);
        }

        searchResult.put("users", users);
        searchResult.put("points", t.getTeamPoints());

        Result res = ok(searchResult);
        return res;
    }

    public Result getRandomTeam(){
        Logger.info("getRandomTeam");

        Team t = db.getRandomTeam();
        if(t == null){return badRequest("{ }");}

        ObjectNode searchResult = Json.newObject();
        searchResult.put("id", t.getId());
        searchResult.put("teamname", t.getTeamname());

        ArrayNode users = searchResult.arrayNode();
        for (Integer u:t.getUsers()) {
            users.add(u);
        }

        searchResult.put("users", users);
        searchResult.put("points", t.getTeamPoints());

        Result res = ok(searchResult);
        return res;
    }

    public Result updateTeam(int id, String teamname, String users, int teamPoints){
        Logger.info("updateTeam");

        Team t = db.getTeam(id);

        if(t!=null){
            t.setTeamname(teamname);

            List<Integer> userList = new ArrayList<>();
            if (!(users.compareTo("\u0002") == 0)){
                String[] s = users.split(",");
                for (int i = 0; i < s.length; i++) {
                    userList.add(Integer.parseInt(s[i]));
                }
            }

            t.setUsers(userList);
            t.setTeamPoints(teamPoints);

            db.update(t);
        }else{
            Logger.info("team not found");
            return badRequest("Team doesn't exist in db");
        }

        return ok("updated User");
    }

    public Result createTeam(String teamname){
        Logger.info("create Team");
        int id = db.nextTID();
        Team t = new Team(id, teamname,new ArrayList<Integer>(), 0);
        db.insert(t);

        return getTeam(id);
    }

    public Result getInbox(int id, int num){
        Logger.info("get inbox");
        User u = db.getUser(id);
        if(u == null){return badRequest("{ }");}

        Set<Integer> inbox = u.getInbox();

        Set<Integer> res = new HashSet<>();
        int i = 0;
        for(Integer current : inbox)
        {
            res.add(current);
            i++;

            if (i >= num){break;}
        }

        inbox.removeAll(res);

        db.update(u);

        Random rand = new Random();
        int c = (int) db.questions().count();
        int missing = num-res.size();
        for (int j = 0; j < missing; j++) {
            int r;
            do {
                r = rand.nextInt(c-1);
            } while (res.contains(r));

            res.add(r);
        }

        ObjectNode searchResult = Json.newObject();
        ArrayNode a = searchResult.arrayNode();
        for (Integer element: res) {
            a.add(element);
        }
        searchResult.put("inbox", a);

        return ok(searchResult);
    }

    public Result addQuestionToInbox(int uid, int qid){
        Logger.info("addQuestionToInbox");

        User u = db.getUser(uid);
        if(u == null){return badRequest("user not found");}

        Question q = db.getQuestion(qid);
        if(q == null){return badRequest("question not found");}

        u.getInbox().add(qid);
        db.update(u);

        return ok("success");
    }

    public Result getQuestion(int id){
        Logger.info("get Question");
        Question q = db.getQuestion(id);
        if(q == null){return badRequest("{ }");}

        ObjectNode searchResult = Json.newObject();

        searchResult.put("id", q.getId());
        searchResult.put("category", q.getCategory());
        searchResult.put("text", q.getText());

        ArrayNode answers = searchResult.arrayNode();
        for (String s:q.getAnswers()) {
            answers.add(s);
        }

        searchResult.put("answers", answers);
        searchResult.put("correctAnswer", q.getCorrectAnswer());

        Result res = ok(searchResult);
        return  res;
    }

    public Result createQuestion(String category, String text, String answers, int correctAnswer){
        Logger.info("create Question");
        int id = db.nextQID();
        Question q = new Question(id, category,text.replaceAll("\\u0001", "?"), answers.split("\\u0001"), correctAnswer);
        db.insert(q);

        return getQuestion(id);
    }

    public Result getRandomQuestions(int num){
        Logger.info("random Questions");
        int c = (int) db.questions().count();
        if(c < num){return badRequest("{ }");}

        Random rand = new Random();
        Set<Integer> s = new HashSet<>();
        for (int i = 0; i < num; i++) {
            int r;
            do {
                r = rand.nextInt(c-1);
            } while (s.contains(r));

            s.add(r);
        }

        ObjectNode searchResult = Json.newObject();
        ArrayNode a = searchResult.arrayNode();
        for (Integer i: s) {
            a.add(i);
        }
        searchResult.put("questions", a);

        return ok(searchResult);
    }

    public synchronized Result matchMe(int ownID, double lat, double lon){
        Logger.info("match me");
        Queue q = db.getQueue();

        OptionalInt i = q.getInProgress(ownID);
        if (!i.isPresent()){
            int res = q.getMatch(ownID, db, lat, lon);
            db.update(q);
            return ok("1," + Integer.toString(res));
        } else {
            Match m = db.getMatch(i.getAsInt());
            if (m.getPlayer1() == ownID){
                return ok("1," + Integer.toString(m.getPlayer2()));
            } else {
                return ok("2," + Integer.toString(m.getPlayer1()));
            }
        }
    }

    public synchronized Result updateMatch(int ownID, int sentOn, int index, String answers, boolean playAgain){
        Logger.info("update Match");

        Queue q = db.getQueue();
        OptionalInt i = q.getInProgress(ownID);
        Match m;
        if (i.isPresent()){
            m = db.getMatch(i.getAsInt());

            if (m.getPlayer1() == ownID){
                m.setSentOnPlayer1(sentOn);
                m.setIndexPlayer1(index);
                List<Integer> a = new ArrayList<>();
                if (!(answers.compareTo("\u0002") == 0)){
                    String[] s = answers.split(",");
                    for (int j = 0; j < s.length; j++) {
                        a.add(Integer.parseInt(s[j]));
                    }
                }

                m.setAnswersPlayer1(a);
                m.setPlayAgain1(playAgain);
            } else {
                m.setSentOnPlayer2(sentOn);
                m.setIndexPlayer2(index);
                List<Integer> a = new ArrayList<>();
                if (!(answers.compareTo("\u0002") == 0)){
                    String[] s = answers.split(",");

                    for (int j = 0; j < s.length; j++) {
                        a.add(Integer.parseInt(s[j]));
                    }
                }
                m.setAnswersPlayer2(a);
                m.setPlayAgain2(playAgain);
            }

            db.update(m);


        } else {
            return ok("{ }");
        }

        ObjectNode searchResult = Json.newObject();

        searchResult.put("player1", m.getPlayer1());
        searchResult.put("player2", m.getPlayer2());
        searchResult.put("sentOnPlayer1", m.getSentOnPlayer1());
        searchResult.put("sentOnPlayer2", m.getSentOnPlayer2());
        searchResult.put("indexPlayer1", m.getIndexPlayer1());
        searchResult.put("indexPlayer2", m.getIndexPlayer2());

        ArrayNode questions = searchResult.arrayNode();
        for (int j = 0; j < m.getQuestions().size(); j++) {
            questions.add(m.getQuestions().get(j));
        }
        searchResult.put("questions", questions);

        ArrayNode answersPlayer1 = searchResult.arrayNode();
        for (int j = 0; j < m.getAnswersPlayer1().size(); j++) {
            answersPlayer1.add(m.getAnswersPlayer1().get(j));
        }
        searchResult.put("answersPlayer1", answersPlayer1);

        ArrayNode answersPlayer2 = searchResult.arrayNode();
        for (int j = 0; j < m.getAnswersPlayer2().size(); j++) {
            answersPlayer2.add(m.getAnswersPlayer2().get(j));
        }
        searchResult.put("answersPlayer2", answersPlayer2);

        searchResult.put("playAgain1", m.isPlayAgain1());
        searchResult.put("playAgain2", m.isPlayAgain2());

        return ok(searchResult);
    }

    public synchronized Result abortMatch(int ownID){
        Logger.info("abort Match");
        Queue q = db.getQueue();
        if (q.abortMatch(ownID, db)){
            db.update(q);
            return ok("match stopped");
        } else {
            return badRequest("match not in progress");
        }
    }

    public synchronized Result resetMatch(int ownID, String questions){
        Logger.info("reset Match");

        Queue q = db.getQueue();
        OptionalInt i = q.getInProgress(ownID);
        Match m;
        if (i.isPresent()){
            m = db.getMatch(i.getAsInt());

            m.setSentOnPlayer1(0);
            m.setSentOnPlayer2(0);
            m.setIndexPlayer1(0);
            m.setIndexPlayer2(0);

            String[] s = questions.split(",");
            List<Integer> a = new ArrayList<>();
            for (int j = 0; j < s.length; j++) {
                a.add(Integer.parseInt(s[j]));
            }
            m.setQuestions(a);

            m.setAnswersPlayer1(new ArrayList<Integer>());
            m.setAnswersPlayer2(new ArrayList<Integer>());
            m.setPlayAgain1(false);
            m.setPlayAgain2(false);
            m.setUpdated(true);

            db.update(m);


        } else {
            return badRequest("{ }");
        }

        ObjectNode searchResult = Json.newObject();

        searchResult.put("player1", m.getPlayer1());
        searchResult.put("player2", m.getPlayer2());
        searchResult.put("sentOnPlayer1", m.getSentOnPlayer1());
        searchResult.put("sentOnPlayer2", m.getSentOnPlayer2());
        searchResult.put("indexPlayer1", m.getIndexPlayer1());
        searchResult.put("indexPlayer2", m.getIndexPlayer2());

        ArrayNode quest = searchResult.arrayNode();
        for (int j = 0; j < m.getQuestions().size(); j++) {
            quest.add(m.getQuestions().get(j));
        }
        searchResult.put("questions", quest);

        ArrayNode answersPlayer1 = searchResult.arrayNode();
        for (int j = 0; j < m.getAnswersPlayer1().size(); j++) {
            answersPlayer1.add(m.getAnswersPlayer1().get(j));
        }
        searchResult.put("answersPlayer1", answersPlayer1);

        ArrayNode answersPlayer2 = searchResult.arrayNode();
        for (int j = 0; j < m.getAnswersPlayer2().size(); j++) {
            answersPlayer2.add(m.getAnswersPlayer2().get(j));
        }
        searchResult.put("answersPlayer2", answersPlayer2);

        searchResult.put("playAgain1", m.isPlayAgain1());
        searchResult.put("playAgain2", m.isPlayAgain2());

        return ok(searchResult);
    }

    public Result fetchMatch(int ownID){
        Logger.info("fetch Match");

        Queue q = db.getQueue();
        OptionalInt i = q.getInProgress(ownID);
        Match m;
        if (i.isPresent()){
            m = db.getMatch(i.getAsInt());

            //if (m.isUpdated()){
                m.setUpdated(false);
                db.update(m);

                ObjectNode searchResult = Json.newObject();

                searchResult.put("player1", m.getPlayer1());
                searchResult.put("player2", m.getPlayer2());
                searchResult.put("sentOnPlayer1", m.getSentOnPlayer1());
                searchResult.put("sentOnPlayer2", m.getSentOnPlayer2());
                searchResult.put("indexPlayer1", m.getIndexPlayer1());
                searchResult.put("indexPlayer2", m.getIndexPlayer2());

                ArrayNode questions = searchResult.arrayNode();
                for (int j = 0; j < m.getQuestions().size(); j++) {
                    questions.add(m.getQuestions().get(j));
                }
                searchResult.put("questions", questions);

                ArrayNode answersPlayer1 = searchResult.arrayNode();
                for (int j = 0; j < m.getAnswersPlayer1().size(); j++) {
                    answersPlayer1.add(m.getAnswersPlayer1().get(j));
                }
                searchResult.put("answersPlayer1", answersPlayer1);

                ArrayNode answersPlayer2 = searchResult.arrayNode();
                for (int j = 0; j < m.getAnswersPlayer2().size(); j++) {
                    answersPlayer2.add(m.getAnswersPlayer2().get(j));
                }
                searchResult.put("answersPlayer2", answersPlayer2);

                searchResult.put("playAgain1", m.isPlayAgain1());
                searchResult.put("playAgain2", m.isPlayAgain2());

                return ok(searchResult);
            /*} else {
                return ok("waiting");
            }*/
        } else {
            return badRequest("{ }");
        }
    }

    public synchronized Result getLeaderboard(int size){
        List<Team> l = db.getLeaderboard(size);

        ObjectNode searchResult = Json.newObject();
        ArrayNode a = searchResult.arrayNode();
        for (int i = 0; i < l.size(); i++) {
            a.add(l.get(i).getId());
        }
        searchResult.put("leaderboard", a);

        return ok(searchResult);
    }
}
