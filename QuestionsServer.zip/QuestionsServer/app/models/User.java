package models;

import java.util.HashSet;
import java.util.Set;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.io.IOException;
import play.Logger;

public class User implements Cloneable{
    @JsonProperty("id")
    private final int id;
    private String username;
    @JsonProperty("email")
    private String email;
    private Set<Integer> inbox = new HashSet<>();
    private int team;
    private int points;
    private int gamesWon;
    private int gamesLose;
    private int questionsSentOn;
    private int questionsRight;
    private int questionsWrong;

    @JsonCreator
    public User(@JsonProperty("id") int id,@JsonProperty("username") String username,@JsonProperty("email") String email,@JsonProperty("inbox") Set<Integer> inbox, @JsonProperty("team") int team,
                @JsonProperty("points") int points,@JsonProperty("gamesWon") int gamesWon, @JsonProperty("gamesLose") int gamesLose,@JsonProperty("questionsSentOn") int questionsSentOn,
                @JsonProperty("questionsRight") int questionsRight,@JsonProperty("questionsWrong") int questionsWrong) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.inbox = inbox;
        this.team = team;
        this.points = points;
        this.gamesWon = gamesWon;
        this.gamesLose = gamesLose;
        this.questionsSentOn = questionsSentOn;
        this.questionsRight = questionsRight;
        this.questionsWrong = questionsWrong;
    }

    public Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            Logger.info("Cloning User failed");
            return null;
        }
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Set<Integer> getInbox() {
        return inbox;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public int getTeam() {
        return team;
    }

    public void setTeam(int team) {
        this.team = team;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getGamesWon() {
        return gamesWon;
    }

    public void setGamesWon(int gamesWon) {
        this.gamesWon = gamesWon;
    }

    public int getGamesLose() {
        return gamesLose;
    }

    public void setGamesLose(int gamesLose) {
        this.gamesLose = gamesLose;
    }

    public int getQuestionsSentOn() {
        return questionsSentOn;
    }

    public void setQuestionsSentOn(int questionsSentOn) {
        this.questionsSentOn = questionsSentOn;
    }

    public int getQuestionsRight() {
        return questionsRight;
    }

    public void setQuestionsRight(int questionsRight) {
        this.questionsRight = questionsRight;
    }

    public int getQuestionsWrong() {
        return questionsWrong;
    }

    public void setQuestionsWrong(int questionsWrong) {
        this.questionsWrong = questionsWrong;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
