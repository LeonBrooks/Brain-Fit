package models;

import org.jongo.MongoCollection;
import org.jongo.MongoCursor;

import javax.inject.*;

import uk.co.panaxiom.playjongo.*;
import play.Logger;

import com.mongodb.MongoClient;
import com.mongodb.DB;
import com.mongodb.MongoClientURI;


import com.google.common.collect.Lists;

import java.util.List;
import java.util.ArrayList;

@Singleton
public class MDB {

    @Inject
    private PlayJongo jongo;

    public static MDB instance = null;

    public MDB(){
        instance = this;
    }

    public static MDB getInstance() {
        return instance;
    }

    public MongoCollection users(){
        MongoCollection users = jongo.getCollection("users");
        return users;
    }

    public MongoCollection NID(){
        MongoCollection nextID = jongo.getCollection("nextID");
        return nextID;
    }

    public MongoCollection teams(){
        MongoCollection teams = jongo.getCollection("teams");
        return teams;
    }

    public MongoCollection questions(){
        MongoCollection questions = jongo.getCollection("questions");
        return questions;
    }

    public MongoCollection queue(){
        MongoCollection queue = jongo.getCollection("queue");
        return queue;
    }

    public MongoCollection matches(){
        MongoCollection matches = jongo.getCollection("matches");
        return matches;
    }

    public Team getTeam(int id){
        return teams().findOne("{id: #}",id).as(Team.class);
    }

    public Team getRandomTeam() {return teams().find().limit(-1).skip((int) (Math.random() * (teams().count() -1))).as(Team.class).next();}

    public List<Team> getLeaderboard(int size){
        MongoCursor<Team> c = teams().find().sort("{points: -1}").as(Team.class);

        List<Team> res = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            if (c.hasNext()){
                res.add(c.next());
            } else {
                break;
            }
        }

        return  res;
    }

    public void insert(Team t){
        teams().save(t);
    }

    public void update(Team t) {
        teams().update("{id: #}",t.getId()).with(t.clone());
    }

    public User getUser(int id){
        return users().findOne("{id: #}",id).as(User.class);
    }

    public User getUser(String email){return users().findOne("{email: #}",email).as(User.class);}

    public void insert(User u){
        users().save(u);
    }

    public void update(User u) {
        users().update("{id: #}",u.getId()).with(u.clone());
    }

    public Match getMatch(int id){
        return matches().findOne("{id: #}",id).as(Match.class);
    }

    public void insert(Match m){
        matches().save(m);
    }

    public void update(Match m) {
        matches().update("{id: #}",m.getId()).with(m.clone());
    }

    public void remove(Match m) {matches().remove("{id: #}", m.getId());}

    public Queue getQueue(){
        Queue q = queue().findOne("{name: #}", "only").as(Queue.class);
        if (q == null){
            queue().save(new Queue());
            q = queue().findOne("{name: #}", "only").as(Queue.class);
        }

        return q;
    }

    public void update(Queue q) {queue().update("{name: #}", "only").with(q.clone());}

    public Question getQuestion(int id){
        return questions().findOne("{id: #}",id).as(Question.class);
    }

    public void insert(Question q){
        questions().save(q);
    }

    public int nextUID(){
        NID n = NID().findOne("{name: #}","only").as(NID.class);
        if (n == null){
            NID().save(new NID());
            n = NID().findOne("{name: #}","only").as(NID.class);
        }
        int res = n.getNextUID();
        NID().update("{name: #}","only").with(n.clone());
        return res;
    }

    public int nextTID(){
        NID n = NID().findOne("{name: #}","only").as(NID.class);
        if (n == null){
            NID().save(new NID());
            n = NID().findOne("{name: #}","only").as(NID.class);
        }
        int res = n.getNextTID();
        NID().update("{name: #}","only").with(n.clone());
        return res;
    }

    public int nextQID(){
        NID n = NID().findOne("{name: #}","only").as(NID.class);
        if (n == null){
            NID().save(new NID());
            n = NID().findOne("{name: #}","only").as(NID.class);
        }
        int res = n.getNextQID();
        NID().update("{name: #}","only").with(n.clone());
        return res;
    }

    public int nextMID(){
        NID n = NID().findOne("{name: #}","only").as(NID.class);
        if (n == null){
            NID().save(new NID());
            n = NID().findOne("{name: #}","only").as(NID.class);
        }
        int res = n.getNextMID();
        NID().update("{name: #}","only").with(n.clone());
        return res;
    }
}
