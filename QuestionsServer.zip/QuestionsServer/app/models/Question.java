package models;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.io.IOException;
import play.Logger;

public class Question implements Cloneable {
    @JsonProperty("id")
    private final int id;
    private final String category;
    private final String text;
    private final String[] answers;
    private final int correctAnswer;

    @JsonCreator
    public Question(@JsonProperty("id")int id, @JsonProperty("category")String category, @JsonProperty("text")String text, @JsonProperty("answers")String[] answers, @JsonProperty("correctAnswer")int correctAnswer) {
        this.id = id;
        this.category = category;
        this.text = text;
        this.answers = answers;
        this.correctAnswer = correctAnswer;
    }

    public int getId() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public String getText() {
        return text;
    }

    public String[] getAnswers() {
        return answers;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }

    public Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            Logger.info("Cloning Question failed");
            return null;
        }
    }
}
