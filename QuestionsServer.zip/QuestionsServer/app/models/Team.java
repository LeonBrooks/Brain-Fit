package models;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.io.IOException;
import play.Logger;

public class Team implements Cloneable{
    @JsonProperty("id")
    private final int id;
    private String teamname;
    private List<Integer> users;
    @JsonProperty("points")
    private int teamPoints;


    @JsonCreator
    public Team(@JsonProperty("id") int id,@JsonProperty("teamname") String teamname,@JsonProperty("users") List<Integer> users,@JsonProperty("teamPoints") int teamPoints) {
        this.id = id;
        this.teamname = teamname;
        this.users = users;
        this.teamPoints = teamPoints;
    }

    public String getTeamname() {
        return teamname;
    }

    public void setTeamname(String teamname) {
        this.teamname = teamname;
    }

    public int getTeamPoints() {
        return teamPoints;
    }

    public void setTeamPoints(int teamPoints) {
        this.teamPoints = teamPoints;
    }

    public List<Integer> getUsers() {
        return users;
    }

    public void setUsers(List<Integer> users){
        this.users = users;
    }

    public int getId() {
        return id;
    }

    public Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            Logger.info("Cloning Team failed");
            return null;
        }
    }
}
