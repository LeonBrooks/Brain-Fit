package models;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.IOException;
import play.Logger;

public class NID implements Cloneable{
    @JsonProperty("name")
    String name = "only";

    private int nextTID = 0;
    private int nextUID = 0;
    private int nextQID = 0;
    private int nextMID = 0;

    public NID(){

    }

    public int getNextTID(){
        int i = nextTID;
        nextTID++;
        return i;
    }

    public int getNextUID(){
        int i = nextUID;
        nextUID++;
        return i;
    }

    public int getNextQID(){
        int i = nextQID;
        nextQID++;
        return i;
    }

    public int getNextMID(){
        int i = nextMID;
        nextMID++;
        return i;
    }

    public Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            Logger.info("Cloning NID failed");
            return null;
        }
    }
}
