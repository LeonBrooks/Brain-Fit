package models;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.io.IOException;
import play.Logger;

public class Match implements  Cloneable{
    @JsonProperty("id")
    private int id;
    private int player1;
    private int player2;
    private int sentOnPlayer1, sentOnPlayer2;
    private int indexPlayer1, indexPlayer2;
    private List<Integer> questions;
    private List<Integer> answersPlayer1;
    private List<Integer> answersPlayer2;
    private boolean playAgain1;
    private boolean playAgain2;
    private boolean updated;

    @JsonCreator
    public Match(@JsonProperty("id")int id, @JsonProperty("player1")int player1, @JsonProperty("player2")int player2){
        this.id = id;
        this.player1 = player1;
        this.player2 = player2;

        sentOnPlayer1 = 0;
        sentOnPlayer2 = 0;
        indexPlayer1 = 0;
        indexPlayer2 = 0;
        questions = new ArrayList<Integer>();
        answersPlayer1 = new ArrayList<Integer>();
        answersPlayer2 = new ArrayList<Integer>();
        playAgain1 = false;
        playAgain2 = false;
        updated = false;
    }

    public int getId() {
        return id;
    }

    public int getPlayer1() {
        return player1;
    }

    public void setPlayer1(int player1) {
        this.player1 = player1;
    }

    public int getPlayer2() {
        return player2;
    }

    public void setPlayer2(int player2) {
        this.player2 = player2;
    }

    public int getSentOnPlayer1() {
        return sentOnPlayer1;
    }

    public void setSentOnPlayer1(int sentOnPlayer1) {
        this.sentOnPlayer1 = sentOnPlayer1;
    }

    public int getSentOnPlayer2() {
        return sentOnPlayer2;
    }

    public void setSentOnPlayer2(int sentOnPlayer2) {
        this.sentOnPlayer2 = sentOnPlayer2;
    }

    public int getIndexPlayer1() {
        return indexPlayer1;
    }

    public void setIndexPlayer1(int indexPlayer1) {
        this.indexPlayer1 = indexPlayer1;
    }

    public int getIndexPlayer2() {
        return indexPlayer2;
    }

    public void setIndexPlayer2(int indexPlayer2) {
        this.indexPlayer2 = indexPlayer2;
    }

    public List<Integer> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Integer> questions) {
        this.questions = questions;
    }

    public List<Integer> getAnswersPlayer1() {
        return answersPlayer1;
    }

    public void setAnswersPlayer1(List<Integer> answersPlayer1) {
        this.answersPlayer1 = answersPlayer1;
    }

    public List<Integer> getAnswersPlayer2() {
        return answersPlayer2;
    }

    public void setAnswersPlayer2(List<Integer> answersPlayer2) {
        this.answersPlayer2 = answersPlayer2;
    }

    public boolean isPlayAgain1() {
        return playAgain1;
    }

    public void setPlayAgain1(boolean playAgain1) {
        this.playAgain1 = playAgain1;
    }

    public boolean isPlayAgain2() {
        return playAgain2;
    }

    public void setPlayAgain2(boolean playAgain2) {
        this.playAgain2 = playAgain2;
    }

    public boolean isUpdated() {
        return updated;
    }

    public void setUpdated(boolean updated) {
        this.updated = updated;
    }

    public Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            Logger.info("Cloning Match failed");
            return null;
        }
    }
}
