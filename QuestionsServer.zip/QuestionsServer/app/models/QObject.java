package models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.io.IOException;
import play.Logger;

public class QObject implements  Cloneable{
    public int id;
    public double lat;
    public double lon;

    @JsonCreator
    public QObject(@JsonProperty("id") int id, @JsonProperty("lat") double lat, @JsonProperty("lon") double lon) {
        this.id = id;
        this.lat = lat;
        this.lon = lon;
    }

    public Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            Logger.info("Cloning QObject failed");
            return null;
        }
    }
}
