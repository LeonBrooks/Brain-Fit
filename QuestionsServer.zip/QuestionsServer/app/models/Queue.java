package models;

import java.util.Map;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.HashMap;
import java.util.OptionalInt;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.io.IOException;
import play.Logger;
import javax.inject.Inject;

public class Queue implements Cloneable {
    @JsonProperty("name")
    String name = "only";

    private java.util.Queue<QObject> q;
    private java.util.Map<Integer, Integer> inProgress;

    public Queue (){
        q = new PriorityBlockingQueue<QObject>();
        inProgress = new HashMap<Integer, Integer>();
    }

    @JsonCreator
    public Queue(@JsonProperty("name") String name,@JsonProperty("q") java.util.Queue<QObject> q,@JsonProperty("inProgress") Map<Integer, Integer> inProgress) {
        this.name = name;
        this.q = q;
        this.inProgress = inProgress;
    }

    public synchronized int getMatch(int ownID, MDB db, double lat, double lon){
        if (q.isEmpty()){
            q.offer(new QObject(ownID, lat, lon));
            return -1;
        }

        if (q.peek().id == ownID){
            return -1;
        }

        if (q.peek().id != ownID){
            double min = Double.MAX_VALUE;
            int res = -1;
            for (QObject o: q) {
                if (o.id != ownID){
                    double current = 0;
                    current += Math.abs(o.lat - lat);
                    current += Math.abs(o.lon - lon);
                    if (current < min){
                        min = current;
                        res = o.id;
                    }
                }
            }

            QObject rem1 = null;
            QObject rem2 = null;
            for (QObject o: q) {
                if (o.id == ownID){
                    rem1 = o;
                }

                if (o.id == res){
                    rem2 = o;
                }
            }
            if (rem1 != null){
                q.remove(rem1);
            }
            if (rem2 != null){
                q.remove(rem2);
            }

            Match m = new Match(db.nextMID(),ownID, res);
            db.insert(m);

            inProgress.put(ownID, m.getId());
            inProgress.put(res, m.getId());

            return  res;
        }

        return -1;
    }

    public synchronized OptionalInt getInProgress(int uid){
        Integer i = inProgress.get(uid);
        if (i == null){
            return OptionalInt.empty();
        } else {
            return  OptionalInt.of(i);
        }
    }

    public synchronized boolean abortMatch(int uid, MDB db){
        Integer i = inProgress.get(uid);
        if (i == null){
            return false;
        } else {
            Match m = db.getMatch(i);
            inProgress.remove(uid);
            if (uid == m.getPlayer1()){
                inProgress.remove(m.getPlayer2());
            } else {
                inProgress.remove(m.getPlayer1());
            }
            db.remove(m);
            return  true;
        }
    }

    public Object clone(){
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            Logger.info("Cloning Queue failed");
            return null;
        }
    }
}
